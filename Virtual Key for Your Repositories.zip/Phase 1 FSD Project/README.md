# LockedMe.com-App
Phase 1 project

# Output
### Code to display the welcome screen. It should display:
## Output 1
Main application window:
Application name and the developer details 

The details of the user interface such as options displaying the user interaction information 

Features to accept the user input to select one of the options listed 

The first option returns the current file names in ascending order. The root directory can be either empty or contain few files or folders in it.

![](images/1.PNG)

## Output 2
Business-level operations window:

Option to add a user specified file to the application

Option to delete a user specified file from the application

Option to search a user specified file from the application

Navigation option to close the current execution context and return to the main context

![](images/2.PNG)

## Output 3
Option to add a user specified file to the application and add contents to it.(Desktop.getDesktop().edit(file) opens the file for adding content on Notepad).

![](images/3.PNG)


## Output 4
Delete a user specified file from the existing directory list

![](images/4.PNG)

## Output 5
Search a user specified file from the main directory

Displayed the result upon successful operation

Displayed the result upon unsuccessful operation

![](images/5.PNG)

## Output 6 and 7
Option to navigate back to the main context

![](images/6.PNG)

Third option to close the main application

![](images/7.PNG)

